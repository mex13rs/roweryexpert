<?php
declare(strict_types=1);

// Brak config.php = instalacja nieukonczona -> JSON zamiast bledu PHP.
if (!is_file(__DIR__ . '/../config.php')) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'error' => 'Instalacja nie zostala zakonczona - uruchom install.php']);
    exit;
}

require __DIR__ . '/../config.php';

auth_require();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    json_out(['success' => true, 'data' => uslugi_list()]);
}

if ($method === 'POST') {
    // 3.1: katalogiem usług zarządza tylko admin (czytanie = wszyscy)
    auth_require_admin();
    // Moduł "katalog usług" wyłączony = zapis i usuwanie nieczynne
    if (!modul('uslugi')) {
        json_fail('Moduł katalogu usług jest wyłączony w ustawieniach panelu.', 403);
    }
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'add') {
        // 3.9: usluga trafia do katalogu wskazanego typu; przy wylaczonym
        // module "hulajnogi" zawsze do katalogu rowerow
        $typ = modul('hulajnogi') ? (string) ($_POST['typ'] ?? 'rower') : 'rower';
        $error = uslugi_add((string) ($_POST['nazwa'] ?? ''), $typ);
        if ($error !== null) {
            json_fail($error, 400);
        }
        json_out(['success' => true, 'data' => uslugi_list()]);
    }

    if ($action === 'remove') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0 || !uslugi_remove($id)) {
            json_fail('Nie znaleziono usługi.', 404);
        }
        json_out(['success' => true, 'data' => uslugi_list()]);
    }

    json_fail('Nieznana akcja.', 400);
}

json_fail('Nieznane żądanie.', 400);