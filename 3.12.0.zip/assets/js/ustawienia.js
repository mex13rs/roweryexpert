        // --- OBSŁUGA SETTINGS MODAL ---
        // Otwiera też klik w nazwę użytkownika w nagłówku (3.6)
        const openSettingsModal = () => {
            settingsModal.classList.add('active');
            loadPhotoStats();
            syncModuleToggles();   // zakładka Moduły: odbij aktualne flagi
        };
        openSettingsBtn?.addEventListener('click', openSettingsModal);

        const currentUserEl = document.getElementById('current-user');
        currentUserEl?.addEventListener('click', openSettingsModal);
        currentUserEl?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openSettingsModal();
            }
        });

        closeSettingsBtn.addEventListener('click', () => {
            settingsModal.classList.remove('active');
            passwordHintEl.textContent = '';
        });

        // Zamknięcie modala po kliknięciu na tło
        settingsModal.addEventListener('click', (e) => {
            if (e.target === settingsModal) {
                settingsModal.classList.remove('active');
                passwordHintEl.textContent = '';
            }
        });

        // PRZEŁĄCZANIE ZAKŁADEK USTAWIEŃ
        // 3.1: pracownik widzi tylko "Ogólne" - przyciski/zakładki admina
        // mogą nie istnieć w DOM, więc wszystko przez ?? i tablicę.
        const SETTINGS_TABS = [
            ['general', tabGeneralBtn, tabGeneralContent],
            ['serwis',  tabSerwisBtn,  tabSerwisContent],
            ['uslugi',  tabUslugiBtn,  tabUslugiContent],
            ['moduly',  tabModulyBtn,  tabModulyContent],
            ['users',   tabUsersBtn,   tabUsersContent],
        ];

        function switchSettingsTab(tabName) {
            const istnieje = Object.fromEntries(SETTINGS_TABS.map(([n, b]) => [n, !!b]));
            // Zakładka usług nie istnieje, gdy moduł wyłączony albo brak uprawnień
            if (tabName === 'uslugi' && (!modulOn('uslugi') || !istnieje.uslugi)) tabName = 'general';
            // Zakładki admina niedostępne dla pracownika -> cofamy do "Ogólne"
            if ((tabName === 'moduly' || tabName === 'users' || tabName === 'serwis') && !istnieje[tabName]) tabName = 'general';

            for (const [name, btn, content] of SETTINGS_TABS) {
                btn?.classList.toggle('active', name === tabName);
                if (content) content.hidden = name !== tabName;
            }
            if (tabName === 'serwis') loadInstDane();
            if (tabName === 'uslugi') renderServiceList();
            if (tabName === 'moduly') syncModuleToggles();
            if (tabName === 'users') loadUsers();
        }

        tabGeneralBtn.addEventListener('click', () => switchSettingsTab('general'));
        tabSerwisBtn?.addEventListener('click', () => switchSettingsTab('serwis'));
        tabUslugiBtn?.addEventListener('click', () => switchSettingsTab('uslugi'));
        tabModulyBtn?.addEventListener('click', () => switchSettingsTab('moduly'));
        tabUsersBtn?.addEventListener('click', () => switchSettingsTab('users'));

        // --- WYMUSZONA ZMIANA HASŁA PO RESECIE (3.8.7) ---
        // must_change_password=1 ustawia reset_potwierdz() - otwieramy
        // Ustawienia -> Ogólne z komunikatem, żeby hasło z maila od razu
        // zmienić na własne (bez tego użytkownik musiał szukać formularza).
        // UWAGI:
        // 1) OWINIĘTE W setTimeout: wywołanie openSettingsModal() w trakcie
        //    ładowania tego pliku strzelało w TDZ (syncModuleToggles sięga
        //    po consty zdefiniowane niżej, np. modulyHint) i zatrzymywało
        //    CAŁY dalszy skrypt - handlery zmiany hasła i zakładek martwe.
        // 2) Po resecie login idzie z ?powitanie=1 - gdy za chwilę pokaże
        //    się okno podsumowania dnia (ten sam warunek co w core.js),
        //    otwieramy ustawienia dopiero po jego zamknięciu, żeby dwa
        //    modale nie stawały jedno na drugim.
        if (currentUserEl?.dataset.mustChange === '1') {
            const otworzUstawienia = () => {
                setTimeout(() => {
                    openSettingsModal();
                    switchSettingsTab('general');
                    if (passwordHintEl) {
                        passwordHintEl.textContent = 'Zalogowałeś się hasłem z wiadomości e-mail — '
                            + 'dla bezpieczeństwa ustaw własne hasło (formularz powyżej).';
                        passwordHintEl.style.color = 'var(--primary-text)';
                    }
                    newPasswordInput?.focus();
                }, 0);
            };
            const powitanieZapowiedziane = !!document.body.dataset.powitanie
                && modulOn('powitanie') && modulOn('kalendarz');
            if (powitanieZapowiedziane) {
                let zrobione = false;
                const poPowitanju = () => {
                    if (zrobione) return;
                    zrobione = true;
                    otworzUstawienia();
                };
                document.getElementById('welcome-modal-ok')?.addEventListener('click', poPowitanju);
                document.getElementById('welcome-modal-close')?.addEventListener('click', poPowitanju);
            } else {
                otworzUstawienia();
            }
        }

        // --- MODUŁY: przełączniki w zakładce Ustawienia -> Moduły ---
        const MODUL_NAZWA = {
            kalendarz: 'Kalendarz', zdjecia: 'Zdjęcia', skaner: 'Skaner QR',
            uslugi: 'Katalog usług', druk: 'Drukowanie', kosz: 'Kosz',
            kolorystyka: 'Kolorystyka', powitanie: 'Powitanie', karta_wydania: 'Karta wydania',
            wykonane: 'Wykonane czynności', hulajnogi: 'Hulajnogi'
        };
        const modToggles = document.querySelectorAll('.mod-toggle');
        const modulyHint = document.getElementById('moduly-hint');

        function syncModuleToggles() {
            // 3.1: u pracownika nie ma zakładki Moduły - niczego nie ruszamy
            if (!modulyHint) return;
            modToggles.forEach(cb => { cb.checked = modulOn(cb.dataset.mod); });
            modulyHint.textContent = '';
        }

        modToggles.forEach(cb => cb.addEventListener('change', async () => {
            const nazwa = cb.dataset.mod;
            const poprzedni = MODULY[nazwa];
            MODULY[nazwa] = cb.checked;
            modulyHint.textContent = 'Zapisywanie…';

            try {
                await saveModules();
                applyModules();
                renderServicesList();
                updateDashboard();

                // Włączenie kalendarza: przywróć domyślny termin, gdy pusty
                if (nazwa === 'kalendarz' && cb.checked && !datePlannedInput.value) {
                    const d = new Date();
                    d.setDate(d.getDate() + 3);
                    datePlannedInput.value = formatDateForInput(d);
                }

                modulyHint.textContent = `Moduł „${MODUL_NAZWA[nazwa] || nazwa}” `
                    + (cb.checked ? 'włączony.' : 'wyłączony.');
                showToast('Zapisano ustawienia modułów.');
            } catch (err) {
                MODULY[nazwa] = poprzedni;
                cb.checked = poprzedni;
                modulyHint.textContent = '';
                showToast(err.message, 'error');
            }
        }));

        // --- USŁUGI (katalog usług w checkboxach) ---
        let services = [];

        // 3.9: osobne katalogi per typ. Segment w zakladce "Dodaj uslugi"
        // pamietajacy wybor na czas sesji; ukryty, gdy modul hulajnogi wylaczony
        // (wtedy renderServiceList pokazuje wszystko - same rekordy "rower").
        let uslugiTypZarz = 'rower';

        function syncSvcTypSeg() {
            document.querySelectorAll('.svc-typ-btn').forEach(b =>
                b.classList.toggle('active', b.dataset.svcTyp === uslugiTypZarz));
        }

        document.getElementById('svc-typ-seg')?.addEventListener('click', (e) => {
            const btn = e.target.closest('.svc-typ-btn');
            if (!btn) return;
            uslugiTypZarz = btn.dataset.svcTyp === 'hulajnoga' ? 'hulajnoga' : 'rower';
            syncSvcTypSeg();
            renderServiceList();
        });

        async function loadServices() {
            // 3.8.10: pobranie i render rozdzielone - wcześniej wyjątek z
            // renderServiceList() (element tylko dla admina, null u pozostałych
            // użytkowników) lądował w catch i po każdym odświeżeniu pokazywał
            // fałszywy toast "Nie udało się pobrać listy usług.", mimo że
            // checkboxy w formularzu renderowały się poprawnie.
            let lista = null;
            try {
                const res = await apiFetch(API_USLUGI);
                const data = await res.json();
                if (data.success) lista = data.data;
            } catch (err) {
                // 401 już pokazał własny toast i wymusza przeładowanie
                if (err.message !== 'Unauthorized') {
                    showToast('Nie udało się pobrać listy usług.', 'error');
                }
                return;
            }
            if (lista) {
                services = lista;
                renderFormServiceCheckboxes();
                renderServiceList();
            }
        }

        // Checkboxy pod polem "Opis usterki"
        function renderFormServiceCheckboxes() {
            serviceCheckboxList.innerHTML = '';
            // 3.9: tylko uslugi aktywnego typu (przed wyborem typu - tlo rowerowe,
            // i tak zablokowane; modul wylaczony = zawsze rower)
            const typ = aktywnyTyp();
            const lista = services.filter(s => (s.typ || 'rower') === typ);
            if (!lista.length) {
                serviceCheckboxList.innerHTML = typ === 'hulajnoga'
                    ? '<p class="service-checkbox-empty">Brak usług dla hulajnogi — dodaj je w Ustawieniach.</p>'
                    : '<p class="service-checkbox-empty">Brak skonfigurowanych usług — dodaj je w Ustawieniach.</p>';
                return;
            }
            lista.forEach(item => {
                const label = document.createElement('label');
                label.className = 'service-check';
                const cb = document.createElement('input');
                cb.type = 'checkbox';
                cb.className = 'service-checkbox';
                cb.value = item.nazwa;
                label.appendChild(cb);
                label.appendChild(document.createTextNode(' ' + item.nazwa));
                serviceCheckboxList.appendChild(label);
            });
        }

        // Lista usług w zakładce "Dodaj usługi"
        function renderServiceList() {
            // 3.8.10: katalog usług w Ustawieniach widzi tylko admin - u
            // pozostałych użytkowników #service-list nie istnieje w DOM
            if (!serviceListEl) return;
            serviceListEl.innerHTML = '';
            // 3.9: segment typu filtruje liste (modul hulajnogi wlaczony);
            // wylaczony = pokazujemy caly katalog jak wczesniej
            const lista = modulOn('hulajnogi')
                ? services.filter(s => (s.typ || 'rower') === uslugiTypZarz)
                : services;
            if (!lista.length) {
                serviceListEl.innerHTML = modulOn('hulajnogi')
                    ? `<li class="service-list-empty">Brak usług dla typu ${uslugiTypZarz === 'hulajnoga' ? 'hulajnoga' : 'rower'}.</li>`
                    : '<li class="service-list-empty">Brak dodanych usług.</li>';
                return;
            }
            lista.forEach(item => {
                const li = document.createElement('li');
                const span = document.createElement('span');
                span.textContent = item.nazwa;
                const rm = document.createElement('button');
                rm.type = 'button';
                rm.className = 'remove-service';
                rm.title = 'Usuń usługę';
                rm.textContent = '×';
                rm.addEventListener('click', () => removeService(item.id));
                li.appendChild(span);
                li.appendChild(rm);
                serviceListEl.appendChild(li);
            });
        }

        async function removeService(id) {
            const service = services.find(s => s.id === id);
            const confirmed = await showConfirmModal(
                'Usuń usługę',
                `Czy na pewno chcesz usunąć usługę „${service ? service.nazwa : ''}” z listy? Zniknie również z checkboxów w formularzu zgłoszenia.`,
                'Usuń'
            );
            if (!confirmed) return;
            try {
                const res = await apiFetch(API_USLUGI, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=remove&id=' + encodeURIComponent(id)
                });
                const data = await res.json();
                if (!data.success) throw new Error(data.error || 'Nie udało się usunąć usługi.');
                services = data.data;
                renderFormServiceCheckboxes();
                renderServiceList();
                showToast('Usunięto usługę.', 'info');
            } catch (err) {
                showToast(err.message, 'error');
            }
        }

        // Elementy zakładki "Dodaj usługi" nie istnieją u pracownika (3.1)
        addServiceBtn?.addEventListener('click', addService);
        newServiceInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                addService();
            }
        });

        async function addService() {
            const nazwa = newServiceInput.value.trim();
            if (!nazwa) {
                showToast('Wpisz nazwę usługi.', 'info');
                newServiceInput.focus();
                return;
            }
            addServiceBtn.disabled = true;
            try {
                const res = await apiFetch(API_USLUGI, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    // 3.9: usluga trafia do katalogu wybranego typu
                    body: 'action=add&nazwa=' + encodeURIComponent(nazwa)
                        + '&typ=' + (modulOn('hulajnogi') ? uslugiTypZarz : 'rower')
                });
                const data = await res.json();
                if (!data.success) throw new Error(data.error || 'Nie udało się dodać usługi.');
                services = data.data;
                newServiceInput.value = '';
                renderFormServiceCheckboxes();
                renderServiceList();
                showToast('Dodano usługę!');
            } catch (err) {
                showToast(err.message, 'error');
            } finally {
                addServiceBtn.disabled = false;
            }
        }

        // STATYSTYKI ZDJĘĆ
        // Łączny limit pojemności na zdjęcia (MAX_PHOTOS_TOTAL_BYTES z config.php)
        // — widoczny przy statystykach w Ustawieniach -> Ogólne
        // Próg ostrzegawczy: od >=80% limitu komunikat po wgrywaniu
        // i czerwone info w statystykach
        const FOTO_WARN_PCT = 80;

        // Tekst ostrzeżenia o zbliżaniu się do limitu (null = poniżej progu)
        function fotoWarnText(bytes) {
            if (!FOTO_LIMIT_MB) return null;
            const limitBytes = FOTO_LIMIT_MB * 1024 * 1024;
            const pct = Math.round(bytes / limitBytes * 100);
            if (pct < FOTO_WARN_PCT) return null;
            return 'Zdjęcia: zużyto ' + pct + '% limitu ' + FOTO_LIMIT_MB
                + ' MB — zostało ' + formatBytes(Math.max(0, limitBytes - bytes))
                + '. Usuń część starych zdjęć.';
        }

        // Bieżące zużycie prosto z API (do ostrzeżeń po wgrywaniu)
        async function photoStatsNow() {
            try {
                const res = await apiFetch(API_KONTO);
                const data = await res.json();
                if (!data.success) return null;
                return { photos: Number(data.data.photos) || 0, bytes: Number(data.data.bytes) || 0 };
            } catch (e) {
                return null;
            }
        }

        // Toast o przekroczeniu progu80% — wywoływany po zapisaniu zgłoszenia
        // ze zdjęciami (musi być PO toaście „Zapisano”, bo nowszy toast
        // zastępuje poprzedni); poniżej progu nic nie pokazuje
        async function notifyFotoWarn() {
            const st = await photoStatsNow();
            const warn = st ? fotoWarnText(st.bytes) : null;
            if (warn) showToast('⚠ ' + warn, 'error');
            return warn;
        }

        async function loadPhotoStats() {
            // 3.1: blok statystyk renderuje tylko admin - bez niego nic nie pobieramy
            if (!statsPhotosEl) return;
            statsPhotosEl.textContent = '…';
            statsSizeEl.textContent = '…';
            try {
                const res = await apiFetch(API_KONTO);
                const data = await res.json();
                if (!data.success) throw new Error(data.error || 'Błąd statystyk');
                const photos = Number(data.data.photos) || 0;
                const bytes = Number(data.data.bytes) || 0;
                statsPhotosEl.textContent = String(photos);
                statsSizeEl.textContent = formatBytes(bytes) + ' / ' + FOTO_LIMIT_MB + ' MB';
                // Info o zużyciu >= progu ostrzegawczego (80% limitu)
                const warn = fotoWarnText(bytes);
                statsWarnEl.hidden = !warn;
                statsWarnEl.textContent = warn ? '⚠ ' + warn : '';
                statsSizeEl.style.color = warn ? 'var(--danger)' : 'var(--primary-text)';
            } catch (err) {
                statsPhotosEl.textContent = '—';
                statsSizeEl.textContent = '—';
                statsWarnEl.hidden = true;
                showToast('Nie udało się pobrać statystyk.', 'error');
            }
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 MB';
            const mb = bytes / (1024 * 1024);
            if (mb >= 1) return mb >= 100 ? Math.round(mb) + ' MB' : mb.toFixed(1).replace('.', ',') + ' MB';
            return Math.max(1, Math.round(bytes / 1024)) + ' KB';
        }

        refreshStatsBtn?.addEventListener('click', loadPhotoStats);

        // ZMIANA HASŁA
        savePasswordBtn.addEventListener('click', async () => {
            const current = currentPasswordInput.value;
            const next = newPasswordInput.value;
            const confirmPass = confirmPasswordInput.value;

            if (!current || !next || !confirmPass) {
                passwordHintEl.textContent = 'Uzupełnij wszystkie pola.';
                passwordHintEl.style.color = 'var(--danger)';
                return;
            }
            if (next.length < 6) {
                passwordHintEl.textContent = 'Nowe hasło musi mieć min. 6 znaków.';
                passwordHintEl.style.color = 'var(--danger)';
                return;
            }
            if (next !== confirmPass) {
                passwordHintEl.textContent = 'Nowe hasła nie są identyczne.';
                passwordHintEl.style.color = 'var(--danger)';
                return;
            }

            passwordHintEl.textContent = 'Zapisywanie…';
            passwordHintEl.style.color = 'var(--text-secondary)';
            savePasswordBtn.disabled = true;

            try {
                const res = await fetch(API_KONTO, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=password&current=' + encodeURIComponent(current) + '&next=' + encodeURIComponent(next),
                    credentials: 'same-origin'
                });
                const data = await res.json();
                if (data.success) {
                    passwordHintEl.textContent = 'Hasło zostało zmienione.';
                    passwordHintEl.style.color = 'var(--success)';
                    currentPasswordInput.value = '';
                    newPasswordInput.value = '';
                    confirmPasswordInput.value = '';
                    showToast('Hasło zmienione!');
                } else {
                    passwordHintEl.textContent = data.error || 'Nie udało się zmienić hasła.';
                    passwordHintEl.style.color = 'var(--danger)';
                }
            } catch (err) {
                passwordHintEl.textContent = 'Błąd połączenia.';
                passwordHintEl.style.color = 'var(--danger)';
            } finally {
                savePasswordBtn.disabled = false;
            }
        });

        // Wylogowanie (koniec sesji dziennej)
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                window.location.href = window.location.pathname + '?logout=1';
            });
        }

        // --- DANE SERWISU: zakładka "Dane serwisu" (edycja po instalacji) ---
        const instAdres = document.getElementById('inst-adres');
        const instMiasto = document.getElementById('inst-miasto');
        const instTelefon = document.getElementById('inst-telefon');
        const instMaps = document.getElementById('inst-maps');
        const instSite = document.getElementById('inst-site');
        const instResetEmail = document.getElementById('inst-reset-email');
        const instHint = document.getElementById('inst-hint');
        const saveInstBtn = document.getElementById('save-inst-btn');

        async function loadInstDane() {
            if (!instAdres) return;
            try {
                const res = await apiFetch(API_USTAWIENIA);
                const data = await res.json();
                if (data.success && data.data.dane_instancji) {
                    const d = data.data.dane_instancji;
                    instAdres.value = d.adres || '';
                    instMiasto.value = d.miasto || '';
                    instTelefon.value = d.telefon || '';
                    instMaps.value = d.maps_url || '';
                    instSite.value = d.site_url || '';
                    instResetEmail.value = d.reset_email || '';
                }
            } catch (e) {
                /* błąd odczuty pomijamy - pola zostaja puste */
            }
        }

        if (saveInstBtn) {
            saveInstBtn.addEventListener('click', async () => {
                instHint.textContent = 'Zapisywanie…';
                instHint.style.color = 'var(--text-secondary)';
                saveInstBtn.disabled = true;

                const body = new URLSearchParams({
                    action: 'dane_instancji',
                    service_address: instAdres.value.trim(),
                    service_city: instMiasto.value.trim(),
                    service_phone: instTelefon.value.trim(),
                    google_maps_url: instMaps.value.trim(),
                    site_url: instSite.value.trim(),
                    reset_email: instResetEmail.value.trim(),
                });

                try {
                    const res = await apiFetch(API_USTAWIENIA, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: body.toString(),
                    });
                    const data = await res.json();
                    if (data.success) {
                        instHint.textContent = 'Zapisano. Zmiany widoczne od razu na wydruku.';
                        instHint.style.color = 'var(--success)';
                        showToast('Dane serwisu zaktualizowane!');
                    } else {
                        instHint.textContent = data.error || 'Nie udało się zapisać.';
                        instHint.style.color = 'var(--danger)';
                    }
                } catch (err) {
                    instHint.textContent = 'Błąd połączenia.';
                    instHint.style.color = 'var(--danger)';
                } finally {
                    saveInstBtn.disabled = false;
                }
            });
        }
